const express = require("express") ;
const mongoose = require("mongoose") ;
const {isValidDocument, errorHandler, validateIdInRequest} = require("./processDataHelper")

const app = express() ;

app.use(express.json()) ;
app.use("/api/cats/:id", validateIdInRequest )

const myDatabase = "cats" ;
const url = `mongodb://localhost:27017/${myDatabase}` ;

mongoose.connect(url) ;
const db = mongoose.connection;
const collection = db.collection("home");

db.on("error", (error)=> console.log("connection error: ", error))
db.once("open", ()=> console.log("Connected to mongoDB"))



app.get("/", (req, res)=>{
    res.send("Heja w expresie gr 1") ;
})

app.get("/api/cats", async (req, res)=>{
    try{
        
        const queryResult =  collection.find({}); // Returns a query object
        const allCats =  await queryResult.toArray();
        res.send(allCats) ;

    } catch(err) {
        errorHandler(err, res)
    }
})

app.get("/api/cats/:id", async (req, res)=>{
    try{
        const document = await collection.findOne(
            {id: req.correctId})
        console.log(document)
        if(!document) {
            return res.status(404).json({message: "Document not found"})
        }
        res.json(document)

    } catch(err) {
        errorHandler(err, res)
    }
})

app.delete("/api/cats/:id", async (req, res)=>{
    try{
        const catToDelete = await collection.deleteOne(
            {id: req.correctId})
        if(catToDelete.deletedCount === 0){
            return res.status(404).json({message: "Document not found"})
        }
        res.json({message: "Hurra udało się skasować kotka!!!"})

    } catch(err){
        errorHandler(err, res)
    }
})

app.post("/api/cats", async (req,res)=>{
    try{
        const newCat = req.body
        if(!isValidDocument(newCat)){
            return res.status(400).json({message: "Invalid document format"})
        }

        const result = await collection.insertOne(newCat)
        if(!result.acknowledged){
            return res.status(500).json({message:"Fail to add a doc"})
        }
        res.status(201).json({message:"Doc added successfully"})


    } catch(err){
        errorHandler(err, res)
    }
})

app.put("/api/cats/:id", async (req,res)=>{
    try{
       
        const catToUpdate = req.body 
        if(!isValidDocument(catToUpdate)){
            return res.status(400).json({message: "Invalid document format"})
        }

        const result = await collection.replaceOne(
            {id: req.correctId}, catToUpdate  )

        if(result.matchedCount===0){
            return res.status(404).json({message:"Doc not found"})
        }

        if(result.modifiedCount===0){
            return res.status(400).json({message:"No changes to apply"})
        }
        res.json({message:"doc replaced"})






    } catch(err){
        errorHandler(err, res)
    }

})


app.patch("/api/cats/:id", async (req,res)=>{
    try{
       
        const catToUpdate = req.body 
        if(!isValidDocument(catToUpdate)){
            return res.status(400).json({message: "Invalid document format"})
        }

        const result = await collection.updateOne(
            {id: req.correctId}, {$set: catToUpdate}  )

        if(result.matchedCount===0){
            return res.status(404).json({message:"Doc not found"})
        }

        if(result.modifiedCount===0){
            return res.status(400).json({message:"No changes to apply"})
        }
        res.json({message:"doc updated"})

    } catch(err){
        errorHandler(err, res)
    }

})




app.listen(8181, ()=>console.log("Server is running on 8181")) ;

process.on('SIGINT', ()=>{
    console.log("Zamykanie połączenia") ;
    db.disconnect( ()=>{
        process.exit();
    })
})



